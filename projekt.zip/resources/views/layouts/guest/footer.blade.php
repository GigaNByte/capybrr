<footer class="footer px-4">
    <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0">
        <div class="flex items-center justify-start space-x-3">
            <div>
                © 2022 GigaMorswin
            </div>
        </div>
        <x-icon-capybara/>
    </div>
</footer>
