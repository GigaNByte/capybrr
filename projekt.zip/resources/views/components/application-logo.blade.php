<a href="/" class="flex flex-col  justify-center items-center">
    <x-icon-capybara/>
    <h1 class="logo-text font-['Montserrat'] text-3xl font-bold text-pink">Capibrr</h1>
</a>
